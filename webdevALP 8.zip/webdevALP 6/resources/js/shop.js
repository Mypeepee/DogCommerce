$(".lnr-heart").click(function () {
    var id = $(this).data("id");
    var route = $(this).data("route");
    var token = $('meta[name="csrf-token"]').attr("content");
    $.ajax({
        url: route,
        type: "POST",
        data: {
            id: id,
            _token: token,
        },
        success: function (response) {
            alert(response.message);
            // Handle success, e.g., display a success message
        },
        error: function (xhr) {
            console.log(xhr.responseText);
            // Handle errors
        },
    });
});

