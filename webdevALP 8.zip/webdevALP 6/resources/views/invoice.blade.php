<!-- resources/views/invoice.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .invoice-details {
            margin-top: 20px;
        }
        .invoice-details p {
            margin: 5px 0;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Invoice</h1>
            <p>Thank you for your purchase!</p>
        </div>
        <div class="invoice-details">
            <h3>Order Summary</h3>
            @foreach($cartItems as $item)
                <p>Item: {{ $item->nama }}</p>
                <p>Price: Rp {{ number_format($item->harga, 0, ',', '.') }}</p>
                <hr>
            @endforeach
            <p><strong>Subtotal:</strong> Rp {{ number_format($subtotal, 0, ',', '.') }}</p>
            <div class="back-button">
                <form action="{{ route('clear.cart') }}" method="POST">
                    @csrf
                    <button type="submit" class="btn btn-primary">Back to Index</button>
                </form>
            </div>
        </div>
        <div class="footer">
            <p>&copy; {{ date('Y') }} Asuku. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
