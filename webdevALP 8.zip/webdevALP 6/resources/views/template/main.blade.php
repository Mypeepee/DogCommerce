@include("template.header")
@yield("body")
@include("template.footer")