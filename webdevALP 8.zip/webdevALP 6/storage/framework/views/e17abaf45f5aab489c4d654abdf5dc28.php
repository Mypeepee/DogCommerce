<!-- resources/views/invoice.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .invoice-details {
            margin-top: 20px;
        }
        .invoice-details p {
            margin: 5px 0;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Invoice</h1>
            <p>Thank you for your purchase!</p>
        </div>
        <div class="invoice-details">
            <h3>Order Summary</h3>
            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>Item: <?php echo e($item->nama); ?></p>
                <p>Price: Rp <?php echo e(number_format($item->harga, 0, ',', '.')); ?></p>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p><strong>Subtotal:</strong> Rp <?php echo e(number_format($subtotal, 0, ',', '.')); ?></p>
            <div class="back-button">
                <form action="<?php echo e(route('clear.cart')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary">Back to Index</button>
                </form>
            </div>
        </div>
        <div class="footer">
            <p>&copy; <?php echo e(date('Y')); ?> Asuku. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
<?php /**PATH /Users/jasnc/Downloads/webdevALP 6/resources/views/invoice.blade.php ENDPATH**/ ?>