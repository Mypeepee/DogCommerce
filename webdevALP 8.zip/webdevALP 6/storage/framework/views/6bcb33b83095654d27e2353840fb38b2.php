

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('body'); ?>
<!-- Banner 1 -->
<div class="container-fluid hero-header d-flex align-items-center" style="height: 700px;">
    <div class="container py-5">
        <div class="row g-5 align-items-center">
            <div class="col-md-12 col-lg-7">
                <h1 class="mb-5 display-3 text-primary">Login</h1>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="position-relative mx-auto">
                        <input class="form-control border-2 border-secondary w-75 py-3 px-4 rounded-pill  mb-3"
                            type="text" placeholder="Username" name="username" value="<?php echo e(old('username')); ?>" required>
                    </div>
                    <div class="position-relative mx-auto">
                        <input class="form-control border-2 border-secondary w-75 py-3 px-4 rounded-pill"
                            type="password" placeholder="Password" name="password" required>
                        <button type="submit"
                            class="btn btn-primary border-2 border-secondary py-3 px-4 position-absolute rounded-pill text-white h-100"
                            style="top: 0; right: 25%;">Login</button>
                    </div>
                </form>
                <div class="form-check w-75" style="margin: 10px;">
                    <input class="form-check-input" type="checkbox" value="" id="rememberMe" name="remember">
                    <label class="form-check-label" for="rememberMe">
                        Remember Me
                    </label>
                </div>
                <div style="display: flex;">
                    <h4 class="mb-3 text-secondary" style=" margin-left: 5px;"><a href="<?php echo e(url('/register')); ?>">Create
                            Account</a></h4>
                    <h4 class="mb-3 text-secondary" style=" margin-left: 50px;"><a
                            href="<?php echo e(url('/forgotpassword')); ?>">Forgot Password</a></h4>
                </div>
            </div>
            <div class="col-md-12 col-lg-5">
                <div id="carouselId" class="carousel slide position-relative" data-bs-ride="carousel">
                    <div class="carousel-inner" role="listbox">

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Hero End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevALP 2\resources\views/login.blade.php ENDPATH**/ ?>