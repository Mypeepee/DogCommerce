
<?php $__env->startSection("title", "JUDUL"); ?>
<?php $__env->startSection("body"); ?>

<!-- Banner 1 -->
<div class="container-fluid py-5 mb-5 hero-header">
    <div class="container py-5">
        <div class="row g-5 align-items-center">
            <div class="col-md-12 col-lg-7">
                <h1 class="mb-5 display-3 text-primary">Retrieve Account</h1>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <form action="<?php echo e(route('requestpassword')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input class="form-control border-2 border-secondary w-75 py-3 px-4 rounded-pill mb-2" type="text" placeholder="Username" id="username" name="username">
                    <div class="position-relative mx-auto">
                        
                        <input class="form-control border-2 border-secondary w-75 py-3 px-4 rounded-pill" type="text" placeholder="Email" id="email" name="email">
                    
                        <button type="submit" class="btn btn-primary border-2 border-secondary py-3 px-4 position-absolute rounded-pill text-white h-100" style="top: 0; right: 25%;">Send Verification Code</button>
                    </div>
</form>

                <h4 class="mb-3 text-secondary" style="margin-top: 10px; margin-left: 5px;"><a href="<?php echo e(url('/login')); ?>">Already Remember Your Password?</a></h4>
            </div>
            <div class="col-md-12 col-lg-5">
                <div id="carouselId" class="carousel slide position-relative" data-bs-ride="carousel">
                    <div class="carousel-inner" role="listbox">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Hero End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevALP 2\resources\views/forgotpassword.blade.php ENDPATH**/ ?>