<?php $__env->startSection("title", "JUDUL"); ?>

<?php $__env->startSection("body"); ?>
<?php echo $__env->make("Template.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Banner 1 -->
<div class="container-fluid hero-header align-items-center">
    <!-- Success message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Error message -->
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    
    <div class="container py-5">
        <div class="row g-5 align-items-center">
            <h1 class="display-3 text-primary">Register</h1>
            <form action="<?php echo e(route('register.form')); ?>" method="POST">                
            <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-6">
                    <input class="form-control border-2 border-secondary py-4 px-4 rounded-pill" type="text"
                            placeholder="Full Name" name="nama" value="<?php echo e(old('nama')); ?>" required style="color: black">

                        <input class="form-control border-2 border-secondary py-4 px-4 rounded-pill mt-4" type="text"
                            placeholder="Alamat" name="alamat" value="<?php echo e(old('alamat')); ?>" required style="color: black">

                        <input class="form-control border-2 border-secondary py-4 px-4 rounded-pill mt-4" type="date"
                            placeholder="Tanggal Lahir" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" required style="color: black">

                        <input class="form-control border-2 border-secondary py-4 px-4 rounded-pill mt-4" type="tel"
                            placeholder="Nomor Telepon" name="nomor_telepon" value="<?php echo e(old('nomor_telepon')); ?>" required style="color: black">
                    </div>
                    <div class="col-md-6">
                    <input class="form-control border-2 border-secondary py-4 px-4 rounded-pill" type="email"
                            placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required style="color: black">

                        <input id="username" class="form-control border-2 border-secondary py-4 px-4 rounded-pill mt-4"
                            type="text" placeholder="Username" name="username" value="<?php echo e(old('username')); ?>" required style="color: black">
                        <div class="position-relative mx-auto">
                            <input id="password" class="form-control border-2 border-secondary py-4 px-4 rounded-pill mt-4"
                                type="password" placeholder="Create Password" name="password" required style="color: black">
                        <div class="position-relative mx-auto">
                        <input id="password_confirm" class="form-control border-2 border-secondary py-4 px-4 rounded-pill mt-4"
                                type="password" placeholder="Confirm Password" name="password_confirmation" required style="color: black">
                            <button type="submit"
                                class="btn btn-primary border-2 border-secondary position-absolute rounded-pill text-white h-100"
                                style="top: 0; right: 0%;">Create Account</button>
                        </div>
                    </div>
                </div>
            </form>
            <h4 class="mb-3 text-secondary" style="margin-top: 10px; margin-left: 5px;"><a
                    href="<?php echo e(url('/login')); ?>">Already Have An Account?</a></h4>
        </div>
        <div class="col-md-12 col-lg-5">
            <div id="carouselId" class="carousel slide position-relative" data-bs-ride="carousel">
                <div class="carousel-inner" role="listbox">
                    <!-- Isi carousel jika diperlukan -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Hero End -->



<?php echo $__env->make("template.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevALP 2\resources\views/register.blade.php ENDPATH**/ ?>